import os
import re
import shutil
from fastapi import FastAPI, Form, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
import pandas as pd
from langchain.agents.agent_types import AgentType
from langchain.agents import load_tools
from langchain_experimental.agents.agent_toolkits import create_pandas_dataframe_agent
from langchain_community.chat_models import ChatOpenAI
from langchain.agents.agent_types import *
from langchain_openai import OpenAI
from fastapi.templating import Jinja2Templates
import time

app = FastAPI()
templates = Jinja2Templates(directory="templates")

# Mount the "/static" directory to serve static files like images
app.mount("/static", StaticFiles(directory="static"), name="static")

# Define the route for serving the index.html file
@app.get("/", response_class=HTMLResponse)
async def index():
    with open(r'DemoFastApi\templates\index.html') as f:
        return f.read()

# Define the route for processing the form data
@app.post("/process")
async def process(request: Request, data_source: str = Form(...), question: str = Form(...)):
    # Ensure that question and data_source are provided
    start_time = time.time()
    if not question or not data_source:
        raise HTTPException(status_code=400, detail="Question and data_source are required fields")

    # Load your CSV data and create agents here
    df_BLK = pd.read_csv('C:/CODE/Demo/export (4).csv')
    df_blk_meta = pd.read_csv('C:/CODE/Demo/df_blk_meta.csv')
    agent_blk_meta = create_pandas_dataframe_agent(OpenAI(temperature=0), df_blk_meta, verbose=True)

    agent_blk_meta = create_pandas_dataframe_agent(
        ChatOpenAI(temperature=0, model="gpt-3.5-turbo-0613"),
        df_blk_meta,
        verbose=True,
        agent_type=AgentType.OPENAI_FUNCTIONS,
    )

    agent_blk = create_pandas_dataframe_agent(OpenAI(temperature=0), df_BLK, verbose=True)

    agent_blk = create_pandas_dataframe_agent(
        ChatOpenAI(temperature=0, model="gpt-3.5-turbo-0613"),
        df_BLK,
        verbose=True,
        agent_type=AgentType.OPENAI_FUNCTIONS,
    )


    if data_source == 'metadata':
        df_a = agent_blk_meta.run(question)
    elif data_source == 'blk':
        df_a = agent_blk.run(question)
    else:
        raise HTTPException(status_code=400, detail="Invalid data_source. Choose 'metadata' or 'blk'")

    # Extract image path if available
    match = re.search(r'\b[\w-]+\.\w+\b', question)
    image_path = None
    if match:
        filename = match.group()
        source_file = f'C:/CODE/Demo/static/{filename}'
        shutil.move(f'C:/CODE/Demo/{filename}', f'C:/CODE/Demo/static/collectionimages')
        image_path = f'/static/collectionimages/{filename}'
        print('**********************************')
        print(source_file)
    end_time = time.time()
    elapsed_time = end_time - start_time
    print(f"Time consumed for processing request: {elapsed_time} seconds")

    # Return the processed data and image path (if available)
    return {'response': df_a, 'image_path': image_path}
    
