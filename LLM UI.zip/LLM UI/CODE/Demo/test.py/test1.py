from flask import Flask, render_template, request, jsonify
import openai
import pandas as pd
import os
from langchain.agents.agent_types import AgentType
from langchain.agents import load_tools
from langchain_experimental.agents.agent_toolkits import create_pandas_dataframe_agent
from langchain.chat_models import ChatOpenAI
from langchain.agents.agent_types import *
from langchain_openai import OpenAI
import regex as re
import base64
import shutil


question ='By taking x_axis as blk_SizeOfCounter and y_axis as blk_SizeOfLKData can you plot a graph and save with scatter-plot.svg'
# question ='how many dataset are present?'
data_source = 'metadata'
# print(question)
# print(data_source)

df_BLK = pd.read_csv('C:\CODE\Demo\export (4).csv')
df_blk_meta=pd.read_csv('C:\CODE\Demo\df_blk_meta.csv')

agent_blk_meta = create_pandas_dataframe_agent(OpenAI(temperature=0), df_blk_meta, verbose=True)

agent_blk_meta = create_pandas_dataframe_agent(
    ChatOpenAI(temperature=0, model="gpt-3.5-turbo-0613"),
    df_blk_meta,
    verbose=False,
    agent_type=AgentType.OPENAI_FUNCTIONS,
)

agent_blk = create_pandas_dataframe_agent(OpenAI(temperature=0), df_BLK, verbose=True)

agent_blk = create_pandas_dataframe_agent(
    ChatOpenAI(temperature=0, model="gpt-3.5-turbo-0613"),
    df_BLK,
    verbose=True,
    agent_type=AgentType.OPENAI_FUNCTIONS,
)
print("next df_a should be printed")
if data_source == 'metadata':
    print("df_a values are ??")
    df_a=agent_blk_meta.run(question)
    print(question)
    print('********************************')
    print(df_a)
    print(type(df_a))
    print('********************************')

elif data_source == 'blk':
    
    df_a=agent_blk.run(question)

else:
    print("Please go back and select a source from the drop down")
# match = re.search(r'!\[.*?\]\((.*?)\)',df_a)
# if match:
#     image_data = match.group(1)
#     print(image_data)

# #Save the image data to a file
# if image_data:
#     with open('Demo', 'w') as f:
#         f.write(base64.b64decode(image_data))
# print(df_a)
match = re.search(r'\b[\w-]+\.\w+\b', question)


if match:
    filename = match.group()
    print(filename)
    source_file = r'C:\CODE\{}'.format(filename)  # Using the filename variable
    destination_folder = r'C:\CODE\Demo\images'
    shutil.copy2(source_file, destination_folder)